waybar folder updated
