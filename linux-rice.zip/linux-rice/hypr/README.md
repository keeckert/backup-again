come back to after tests:
- milans multimedia key bndings

out of files from milan time to continue
