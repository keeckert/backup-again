#!/bin/bash
# Change grouping behavior for Hyprland so groups swallow dwindle children

GROUP_DIRECTION=$1


focused_ws=$(hyprctl activeworkspace -j | jq '.id')

active_addr=$(hyprctl activewindow -j | jq -r '.address')
active_loc=$(hyprctl activewindow -j | jq -r '.at' | tr -d ',')

active_x=$(awk 'NR==2 {print $1}' <<< "$active_loc")
active_y=$(awk 'NR==3 {print $1}' <<< "$active_loc")

echo "Toggling group at [$active_x, $active_y]: $(hyprctl dispatch togglegroup "$active_window")"

now_grouped=$(hyprctl activewindow -j | jq -r '.grouped')

if [[ $now_grouped != "[]" ]]; then
    windows=$(hyprctl clients -j \
        | jq -r --argjson id "$focused_ws" --arg active "$active_addr" '
            .[] 
            | select(.workspace.id == $id) 
            | select(.address != $active) 
            | select(.floating == false)
            | select(.pinned == false)
            | "\(.address) \(.at) \(.class)"')
        
    while IFS= read -r window; do
        address=$(echo $window | awk '{print $1}')
        loc=$(echo $window | awk '{print $2}')
        class=$(echo $window | awk '{print $3}')

        loc_x=$(echo $loc | cut -d'[' -f2 | cut -d',' -f1)
        loc_y=$(echo $loc | cut -d']' -f1 | cut -d',' -f2)

        echo "Focusing $class: $(hyprctl dispatch focuswindow address:$address)"

        if [[ $GROUP_DIRECTION == 'vertical' ]]; then
            if [[ $loc_y -lt $active_y ]]; then
                echo "Moving $class at [$loc_x, $loc_y] down: $(hyprctl dispatch moveintogroup d)"
            elif [[ $loc_y -gt $active_y ]]; then
                echo "Moving $class at [$loc_x, $loc_y] up: $(hyprctl dispatch moveintogroup u)"
            else
                echo "Not on same column"
            fi
        elif [[ $GROUP_DIRECTION == 'horizontal' ]]; then
            if [[ $loc_x -lt $active_x ]]; then
                echo "Moving $class at [$loc_x, $loc_y] right: $(hyprctl dispatch moveintogroup r)"
            elif [[ $loc_x -gt $active_x ]]; then
                echo "Moving $class at [$loc_x, $loc_y] left: $(hyprctl dispatch moveintogroup l)"
            else
                echo "Not on same row"
            fi
        else
            echo "Invalid group direction: $GROUP_DIRECTION"
            exit 1
        fi
    done <<< "$windows"

    echo "Refocusing active window: $(hyprctl dispatch focuswindow address:$active_addr)"
fi

